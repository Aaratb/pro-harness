import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
const source = '/Users/aaratbhatnagar/Desktop/Workspace Personal/Pro-harness';
const audit = '/private/tmp/pro-parity-audit.1Lnfhp';
const destination = path.join(audit, 'frozen');
const selected = ['commands','skills','agents','mcps','schemas','scripts','config','hooks','rules','docs','adapters','README.md','NOTICE','package.json'];
const files = [];
const hash = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
function copy(file, relative, category) {
  const st = fs.lstatSync(file);
  if (st.isDirectory()) {
    for (const entry of fs.readdirSync(file).sort()) {
      if (['node_modules','.git','.DS_Store','generated'].includes(entry)) continue;
      copy(path.join(file,entry),path.join(relative,entry),category);
    }
    return;
  }
  const content = fs.readFileSync(file);
  const target = path.join(destination,category,relative);
  fs.mkdirSync(path.dirname(target),{recursive:true});
  fs.writeFileSync(target,content,{flag:'wx'});
  files.push({category,path:file,relative,sha256:hash(content),bytes:content.length,...(st.isSymbolicLink()?{symlink:fs.readlinkSync(file),resolved:fs.realpathSync(file)}:{})});
}
if (process.argv.includes('--verify')) {
  const manifest=JSON.parse(fs.readFileSync(path.join(audit,'freeze.json')));
  const changes=manifest.files.filter(f=>!fs.existsSync(f.path)||hash(fs.readFileSync(f.path))!==f.sha256);
  console.log(JSON.stringify({checked:manifest.files.length,changed:changes.map(f=>f.path)}));
  if(changes.length) process.exitCode=1;
} else {
  for(const relative of selected) if(fs.existsSync(path.join(source,relative))) copy(path.join(source,relative),relative,'canonical');
  copy('/Users/aaratbhatnagar/.pro-harness/runtime-adapters/manifest.json','manifest.json','bindings');
  for(const runtime of ['claude','codex']) {
    copy(`/Users/aaratbhatnagar/.pro-harness/runtime-adapters/${runtime}`,runtime,'bindings');
  }
  const manifest={created_at:new Date().toISOString(),source_root:source,audit_root:audit,canonical_binding:'/Users/aaratbhatnagar/.pro-harness/current',files};
  fs.writeFileSync(path.join(audit,'freeze.json'),JSON.stringify(manifest,null,2),{flag:'wx'});
  console.log(JSON.stringify({files:files.length,bytes:files.reduce((n,f)=>n+f.bytes,0),audit_root:audit}));
}
