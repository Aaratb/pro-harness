---
name: architecture-explanation-diagrams
description: "Produce a source-backed architecture walkthrough with the smallest complete set of component, sequence, state, data, and failure diagrams."
---

# Architecture Explanation Diagrams

Build one evidence-linked component inventory and reuse it across every diagram and explanation. Cover the architecture flow, component view, primary execution sequence, code-execution flow, and highest-risk failure sequence with the smallest legible set of views; one view may cover more than one purpose. Reuse earlier option and design views rather than redraw them at the end.

Add state, data, asynchronous, deployment, or decision views only when material. Use an applicability matrix and a path ledger covering primary success, alternatives, rejection, timeout, retry, duplication, reordering, async work, overload, partition, recovery, races, and unknowns. Represent conditional and concurrent behavior explicitly.

Use the same component identifiers across views, contracts, and handoff slices. Label relationships with the contract or data transferred and direction; distinguish module, process, deployment, and trust boundaries. A box labeled “service” is not an explanation of its responsibility. Keep proposed behavior visually or textually distinct from observed existing behavior, and link current claims to source evidence. For greenfield designs, show proposed execution steps without invented files or line numbers.

Follow one meaningful user operation through entry, authority check, invariant ownership, durable effect, and visible result. In its highest-risk failure sequence, show where the outcome becomes uncertain, what the caller sees, who detects it, and how recovery avoids another harmful effect. Do not add irrelevant distributed failure paths to a local decision merely to fill the ledger.

Check cross-view consistency: a sequence participant must exist in the component inventory; an arrow must respect the declared contract and authority; failure recovery must agree with data ownership and the retry policy. Reconcile mismatches before using the views to explain or certify a decision. Local Mermaid source is sufficient when external rendering is unavailable or unapproved; do not claim a rendered view was inspected.

Walk through the decision, rejected alternatives, choice costs, reuse assessment, consistency decisions, edge-case stopping rule, consequences, and residual risks. Local source remains canonical; external rendering is optional and separately authorized.

Write or return `EXPLAIN.md` beneath the caller-supplied `artifact_root` and ask the author to correct misunderstandings before sealing it.

Static lanes return content in the caller's report contract; only the orchestrator writes it. Keep diagrams as shared explanatory evidence, not extra approval gates or a separate documentation workflow.
