# Comprehension contract

Questions regulate learning depth; they are not decoration.

## Question sources

Every question, option, and explanation resolves to confirmed claims already taught in the current generation. If a fact is inferred or out of scope, replace it with a confirmed taught fact or record that the concept cannot be tested.

Use four cumulative backbone shapes when applicable:

1. order the action's evidenced hops;
2. identify where a demonstrated rule is enforced;
3. predict a demonstrated data or state change;
4. predict what runs next and whether the caller waits.

## Learning mechanics

- One prediction prompt opens each learning phase and is explicitly resolved later.
- Preparation sets from the trace phase onward include one or two earlier concepts.
- Distractors represent plausible misconceptions grounded in the course, not invented behavior.
- Correct positions and option lengths are balanced across a set.
- Feedback explains why each answer is right or wrong and points to the taught model.
- Each capability closes with the concrete new ability it contributes. Final delivery consolidates five distinct course-level outcomes without repeating a fixed five-item list per small capability.
- The terminal gate includes one free-text trace explanation for later human or evidence-based feedback.

The quiz measures the reader's understanding. It never scores repository quality, correctness, security, or performance.

## Diagnose a misconception

Ask the reader to predict an evidenced consequence, not recall a filename or recognize phrasing copied from the explanation. Specify the starting state and boundary conditions so the taught model yields one unambiguous answer. Compare adjacent concepts the course actually distinguished, such as accepting work versus completing it, or a local wrapper versus its external dependency. An option can describe a plausible misconception, but its rationale must explain why confirmed evidence rules it out under those conditions.

For each answer, explain the causal step that makes it right or wrong and point back to the relevant taught claims. If two options could be correct because context is missing, repair the question rather than blaming the learner. Do not manufacture a runtime guarantee, hidden business rule or hypothetical failure as a fact in order to grade a question.

The free-text teach-back asks for a short trace in the reader's own words: what enters, which decision matters, what changes, what returns and what remains unknown. When an actual answer arrives, identify the specific mistaken link, re-ground it and give a targeted explanation or follow-up rather than repeating the whole lesson. If it exposes an error in the course, refresh the owning capability and affected dependents before relying on the corrected claim.

Prediction prompts and practice are not approval gates and do not block publication while awaiting chat answers. Preserve unanswered as unanswered. The offline course grades only its supported option questions; it must not claim to evaluate free-text understanding or overall mastery automatically.
