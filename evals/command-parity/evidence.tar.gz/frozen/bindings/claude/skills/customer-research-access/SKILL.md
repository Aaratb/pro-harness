---
name: customer-research-access
description: "Establish source-specific authority and acquire bounded customer-research evidence through an existing approved connector, CLI or export. Use for warehouse, research-repository or fieldwork access planning and authorized acquisition, not for interpreting findings or treating configured tools as permission."
---

Canonical harness root (`HARNESS_ROOT`): `/Users/aaratbhatnagar/.pro-harness/current`.
Use this root for every harness-owned file, including nested references and shell examples; interpret canonical `~/.agents` prefixes as this root, not another installation.
`HARNESS_ROOT` is not automatically exported: set it to this root when a shell example needs it, expand a leading tilde before use, and quote filesystem paths.
Resolve named canonical skills under `/Users/aaratbhatnagar/.pro-harness/current/skills/<name>/SKILL.md` and pass the same root to delegated agents.
Repository-local artifact paths are unchanged; never redirect them into the harness installation.

Read `/Users/aaratbhatnagar/.pro-harness/current/skills/customer-research-access/SKILL.md` completely and execute it as the canonical skill contract.
Resolve every relative reference against `/Users/aaratbhatnagar/.pro-harness/current/skills/customer-research-access/`.
Preserve the user request and arguments exactly. Do not reconstruct the skill from memory.
