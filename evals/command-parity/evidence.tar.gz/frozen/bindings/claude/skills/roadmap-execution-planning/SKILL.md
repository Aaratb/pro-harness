---
name: roadmap-execution-planning
description: "Form or challenge a provisional cross-functional execution view for a human-selected feature set using supplied notes, dependencies and capacity. Use before delivery commitments or when assumptions change; does not select the roadmap, write a PRD or decompose engineering tasks."
---

Canonical harness root (`HARNESS_ROOT`): `/Users/aaratbhatnagar/.pro-harness/current`.
Use this root for every harness-owned file, including nested references and shell examples; interpret canonical `~/.agents` prefixes as this root, not another installation.
`HARNESS_ROOT` is not automatically exported: set it to this root when a shell example needs it, expand a leading tilde before use, and quote filesystem paths.
Resolve named canonical skills under `/Users/aaratbhatnagar/.pro-harness/current/skills/<name>/SKILL.md` and pass the same root to delegated agents.
Repository-local artifact paths are unchanged; never redirect them into the harness installation.

Read `/Users/aaratbhatnagar/.pro-harness/current/skills/roadmap-execution-planning/SKILL.md` completely and execute it as the canonical skill contract.
Resolve every relative reference against `/Users/aaratbhatnagar/.pro-harness/current/skills/roadmap-execution-planning/`.
Preserve the user request and arguments exactly. Do not reconstruct the skill from memory.
