---
name: roadmap-human-review
description: "Reconcile human feedback on a product backlog or roadmap, explaining edits, conflicting revisions, decision scope and note impacts while preserving the human's choices. Use for supplied comments, reviewed rows or feedback exports; does not authenticate approvals or persist accepted state."
---

Canonical harness root (`HARNESS_ROOT`): `/Users/aaratbhatnagar/.pro-harness/current`.
Use this root for every harness-owned file, including nested references and shell examples; interpret canonical `~/.agents` prefixes as this root, not another installation.
`HARNESS_ROOT` is not automatically exported: set it to this root when a shell example needs it, expand a leading tilde before use, and quote filesystem paths.
Resolve named canonical skills under `/Users/aaratbhatnagar/.pro-harness/current/skills/<name>/SKILL.md` and pass the same root to delegated agents.
Repository-local artifact paths are unchanged; never redirect them into the harness installation.

Read `/Users/aaratbhatnagar/.pro-harness/current/skills/roadmap-human-review/SKILL.md` completely and execute it as the canonical skill contract.
Resolve every relative reference against `/Users/aaratbhatnagar/.pro-harness/current/skills/roadmap-human-review/`.
Preserve the user request and arguments exactly. Do not reconstruct the skill from memory.
