---
description: "Pro-level repository learning course with evidence-grounded explanations, diagrams, reference material, and comprehension practice."
argument-hint: "<repository | module | question> [--phase <1-8>] [--capability <name>] [--feature <customer-action>] [--audience pm|eng|staff|fsb] [--agent-diff <ref|--working>] [--doubts <question>] [--fast] [--yolo]"
---

Canonical harness root (`HARNESS_ROOT`): `/Users/aaratbhatnagar/.pro-harness/current`.
Use this root for every harness-owned file, including nested references and shell examples; interpret canonical `~/.agents` prefixes as this root, not another installation.
`HARNESS_ROOT` is not automatically exported: set it to this root when a shell example needs it, expand a leading tilde before use, and quote filesystem paths.
Resolve named canonical skills under `/Users/aaratbhatnagar/.pro-harness/current/skills/<name>/SKILL.md` and pass the same root to delegated agents.
Repository-local artifact paths are unchanged; never redirect them into the harness installation.

Read `/Users/aaratbhatnagar/.pro-harness/current/commands/explainer-pro.md` completely and execute it as the canonical command contract.
Preserve the user request and arguments exactly. Do not reconstruct the workflow from memory.
