---
description: "Assess business, product, marketing, engineering, and operational outcomes against intent using authorized aggregate evidence and proportionate analysis."
argument-hint: "<initiative, feature or release> [decision, intended outcome, evidence, evaluation date] [--phase <1|2|3|4|intent|evidence|assess|recommend>]"
---

Canonical harness root (`HARNESS_ROOT`): `/Users/aaratbhatnagar/.pro-harness/current`.
Use this root for every harness-owned file, including nested references and shell examples; interpret canonical `~/.agents` prefixes as this root, not another installation.
`HARNESS_ROOT` is not automatically exported: set it to this root when a shell example needs it, expand a leading tilde before use, and quote filesystem paths.
Resolve named canonical skills under `/Users/aaratbhatnagar/.pro-harness/current/skills/<name>/SKILL.md` and pass the same root to delegated agents.
Repository-local artifact paths are unchanged; never redirect them into the harness installation.

Read `/Users/aaratbhatnagar/.pro-harness/current/commands/outcome-pro.md` completely and execute it as the canonical command contract.
Preserve the user request and arguments exactly. Do not reconstruct the workflow from memory.
