---
description: "Pro-level system architecture design and audit with typed evidence, independent verification, explicit consent, and a validated feature handoff."
argument-hint: "<system, feature, or repository scope> [--design|--audit|--mixed|--adr-only <decision>] [--slug <slug>] [--focus <question>] [--repos <path,...>] [--fast] [--yolo] [--live <environment>]"
---

Canonical harness root (`HARNESS_ROOT`): `/Users/aaratbhatnagar/.pro-harness/current`.
Use this root for every harness-owned file, including nested references and shell examples; interpret canonical `~/.agents` prefixes as this root, not another installation.
`HARNESS_ROOT` is not automatically exported: set it to this root when a shell example needs it, expand a leading tilde before use, and quote filesystem paths.
Resolve named canonical skills under `/Users/aaratbhatnagar/.pro-harness/current/skills/<name>/SKILL.md` and pass the same root to delegated agents.
Repository-local artifact paths are unchanged; never redirect them into the harness installation.

Read `/Users/aaratbhatnagar/.pro-harness/current/commands/architecture-pro.md` completely and execute it as the canonical command contract.
Preserve the user request and arguments exactly. Do not reconstruct the workflow from memory.
